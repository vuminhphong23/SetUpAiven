<?php
    
    session_start();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        include('../Model/aivenDbConnection.php');

        $TK = $_POST['txtTenTaiKhoan'];
        $MK = $_POST['txtMatKhau'];

        $query = $db->prepare("SELECT * FROM User WHERE TenUser = ? AND MatKhau = ?");
        $query->execute(array($TK, $MK));
        $user = $query->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $_SESSION['IsLogin'] = true;
            header("Location: ../View/result_login.php");
            exit();
        } else {
            echo "<script>
                        if (confirm('Sai tài khoản hoặc mật khẩu!!')) {
                            window.location.href = '../View/form_login.php';
                        } else {
                        }
                    </script>";
        }
    } else {
        header("Location: ../View/form_login.php");
        exit();
    }
?>
