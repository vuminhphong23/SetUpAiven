

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Sach</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #dddddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }

    </style>
</head>
<body>
    <?php
    
        include('../Model/aivenDbConnection.php');

        // Lấy dữ liệu từ biểu mẫu đăng nhập
        
            $query = $db->prepare("SELECT * FROM Sach");
            $query->execute();
            $listSach = $query->fetchAll(PDO::FETCH_ASSOC);
            ?>
            <table>
                <thead>
                    <tr>
                        <th>Mã sách</th>
                        <th>Tên sách</th>
                        <th>Số lượng</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($listSach as $sach): ?>
                        <tr>
                            <td><?php echo $sach['MaSach']; ?></td>
                            <td><?php echo $sach['TenSach']; ?></td>
                            <td><?php echo $sach['SoLuong']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        
    

</body>
</html>
