INSERT INTO Sach (MaSach, TenSach, SoLuong) VALUES
('S1', 'Sach Toan', 10),
('S2', 'Sach Van', 20),
('S3', 'Sach Tieng Anh', 15),
('S4', 'Sach Dia Ly', 12),
('S5', 'Sach Lich Su', 8);


INSERT INTO User (TenUser, MatKhau) VALUES
('phong', 'phong123'),
('ducanh', 'ducanh123'),
('kien', 'kien123'),
('bim', 'bim123'),
('binh', 'binh123');